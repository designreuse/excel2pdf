package cz.wt.convertor.main.utils;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 * 
 * @author diblik
 * @version $Revision$
 */
public class MessagesUtils {

  public static void showInfo(Component component, String infoMsg) {
    JOptionPane.showMessageDialog(component,
        infoMsg,
        "Info dialog",
        JOptionPane.INFORMATION_MESSAGE);
  }

  public static void showWarning(Component component, String warnMsg) {
    JOptionPane.showMessageDialog(component,
        warnMsg,
        "Warning dialog",
        JOptionPane.WARNING_MESSAGE);
  }

  public static void showError(Component component, String errorMsg) {
    JOptionPane.showMessageDialog(component,
        errorMsg,
        "Error dialog",
        JOptionPane.ERROR_MESSAGE);

  }
}
